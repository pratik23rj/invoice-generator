# 🧾 BillMatic — GST Invoice Generator for India

A professional, India-specific GST invoice generator built with React + Shopify Polaris.

## Features

- ✅ Full GST support — CGST+SGST (intrastate) and IGST (interstate)
- ✅ Seller & buyer details with GSTIN, PAN validation
- ✅ Line items with HSN/SAC codes, multiple units, per-item tax rates
- ✅ Auto discount & tax calculation in Indian number format
- ✅ Amount in words (Rupees) on PDF
- ✅ Bank details section for payment instructions
- ✅ Custom notes & terms and conditions
- ✅ Download as professional PDF
- ✅ Live invoice preview
- ✅ Shopify Polaris design system UI
- ✅ Fully responsive

## Local Development

```bash
npm install
npm run dev
```

## Build for Production

```bash
npm run build
```

## Deploy to Vercel

### Option 1 — Vercel CLI
```bash
npm i -g vercel
vercel
```

### Option 2 — GitHub + Vercel Dashboard
1. Push this repo to GitHub
2. Go to https://vercel.com/new
3. Import the GitHub repo
4. Framework: **Vite**
5. Build Command: `npm run build`
6. Output Directory: `dist`
7. Click **Deploy**

No environment variables needed.
