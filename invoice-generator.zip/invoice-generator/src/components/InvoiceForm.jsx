import { INDIAN_STATES, GST_RATES, UNITS } from '../utils/indianData.js';

export default function InvoiceForm({ data, onUpdateSeller, onUpdateBuyer, onUpdateInvoice, onUpdateItem, onAddItem, onRemoveItem }) {
  const { seller, buyer, invoice, items } = data;

  return (
    <div>
      {/* INVOICE INFO */}
      <div className="card">
        <div className="card-header">
          <div className="card-header-icon blue">📋</div>
          <div>
            <div className="card-title">Invoice Information</div>
            <div className="card-subtitle">Invoice number, dates & payment details</div>
          </div>
        </div>
        <div className="card-body">
          <div className="form-row cols-3" style={{ marginBottom: 16 }}>
            <div className="form-group">
              <label className="form-label">Invoice No <span className="req">*</span></label>
              <input value={invoice.number} onChange={e => onUpdateInvoice({ number: e.target.value })} placeholder="INV-2024-001" />
            </div>
            <div className="form-group">
              <label className="form-label">Invoice Date <span className="req">*</span></label>
              <input type="date" value={invoice.date} onChange={e => onUpdateInvoice({ date: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label">Due Date</label>
              <input type="date" value={invoice.dueDate} onChange={e => onUpdateInvoice({ dueDate: e.target.value })} />
            </div>
          </div>
          <div className="form-row cols-3">
            <div className="form-group">
              <label className="form-label">Place of Supply <span className="req">*</span></label>
              <select value={invoice.placeOfSupply} onChange={e => onUpdateInvoice({ placeOfSupply: e.target.value })}>
                <option value="">Select State</option>
                {INDIAN_STATES.map(s => <option key={s.code} value={s.name}>{s.code} – {s.name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Payment Terms</label>
              <select value={invoice.paymentTerms} onChange={e => onUpdateInvoice({ paymentTerms: e.target.value })}>
                <option>Immediate</option>
                <option>Net 15</option>
                <option>Net 30</option>
                <option>Net 45</option>
                <option>Net 60</option>
                <option>On Delivery</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">PO Number</label>
              <input value={invoice.poNumber} onChange={e => onUpdateInvoice({ poNumber: e.target.value })} placeholder="PO-12345" />
            </div>
          </div>
        </div>
      </div>

      {/* SELLER */}
      <div className="card">
        <div className="card-header">
          <div className="card-header-icon green">🏢</div>
          <div>
            <div className="card-title">Your Business (Seller)</div>
            <div className="card-subtitle">Your company / individual details</div>
          </div>
        </div>
        <div className="card-body">
          <div className="form-row cols-2" style={{ marginBottom: 14 }}>
            <div className="form-group">
              <label className="form-label">Business Name <span className="req">*</span></label>
              <input value={seller.name} onChange={e => onUpdateSeller({ name: e.target.value })} placeholder="Acme Private Limited" />
            </div>
            <div className="form-group">
              <label className="form-label">GSTIN</label>
              <input value={seller.gstin} onChange={e => onUpdateSeller({ gstin: e.target.value.toUpperCase() })} placeholder="22AAAAA0000A1Z5" maxLength={15} style={{ fontFamily: 'var(--font-mono)' }} />
              <span className="form-help">15-digit GST Identification Number</span>
            </div>
          </div>
          <div className="form-row cols-2" style={{ marginBottom: 14 }}>
            <div className="form-group">
              <label className="form-label">PAN Number</label>
              <input value={seller.pan} onChange={e => onUpdateSeller({ pan: e.target.value.toUpperCase() })} placeholder="AAAAA9999A" maxLength={10} style={{ fontFamily: 'var(--font-mono)' }} />
            </div>
            <div className="form-group">
              <label className="form-label">State <span className="req">*</span></label>
              <select value={seller.state} onChange={e => onUpdateSeller({ state: e.target.value })}>
                <option value="">Select State</option>
                {INDIAN_STATES.map(s => <option key={s.code} value={s.name}>{s.name}</option>)}
              </select>
            </div>
          </div>
          <div className="form-group" style={{ marginBottom: 14 }}>
            <label className="form-label">Address</label>
            <textarea rows={2} value={seller.address} onChange={e => onUpdateSeller({ address: e.target.value })} placeholder="Street address, building, area" />
          </div>
          <div className="form-row cols-3" style={{ marginBottom: 14 }}>
            <div className="form-group">
              <label className="form-label">City</label>
              <input value={seller.city} onChange={e => onUpdateSeller({ city: e.target.value })} placeholder="Mumbai" />
            </div>
            <div className="form-group">
              <label className="form-label">PIN Code</label>
              <input value={seller.pincode} onChange={e => onUpdateSeller({ pincode: e.target.value })} placeholder="400001" maxLength={6} />
            </div>
            <div className="form-group">
              <label className="form-label">Phone</label>
              <input value={seller.phone} onChange={e => onUpdateSeller({ phone: e.target.value })} placeholder="+91 98765 43210" />
            </div>
          </div>
          <div className="form-group" style={{ marginBottom: 14 }}>
            <label className="form-label">Email</label>
            <input type="email" value={seller.email} onChange={e => onUpdateSeller({ email: e.target.value })} placeholder="billing@company.com" />
          </div>

          <div className="divider" />

          <div style={{ marginBottom: 10 }}>
            <div style={{ fontSize: '0.8125rem', fontWeight: 700, color: 'var(--color-text-subdued)', marginBottom: 12, textTransform: 'uppercase', letterSpacing: '0.5px' }}>Bank Details (Optional)</div>
          </div>
          <div className="form-row cols-3">
            <div className="form-group">
              <label className="form-label">Bank Name</label>
              <input value={seller.bankName} onChange={e => onUpdateSeller({ bankName: e.target.value })} placeholder="State Bank of India" />
            </div>
            <div className="form-group">
              <label className="form-label">Account Number</label>
              <input value={seller.accountNo} onChange={e => onUpdateSeller({ accountNo: e.target.value })} placeholder="XXXXXXXXXXXX" style={{ fontFamily: 'var(--font-mono)' }} />
            </div>
            <div className="form-group">
              <label className="form-label">IFSC Code</label>
              <input value={seller.ifsc} onChange={e => onUpdateSeller({ ifsc: e.target.value.toUpperCase() })} placeholder="SBIN0001234" style={{ fontFamily: 'var(--font-mono)' }} />
            </div>
          </div>
        </div>
      </div>

      {/* BUYER */}
      <div className="card">
        <div className="card-header">
          <div className="card-header-icon orange">👤</div>
          <div>
            <div className="card-title">Bill To (Buyer / Customer)</div>
            <div className="card-subtitle">Customer billing details</div>
          </div>
        </div>
        <div className="card-body">
          <div className="form-row cols-2" style={{ marginBottom: 14 }}>
            <div className="form-group">
              <label className="form-label">Customer Name <span className="req">*</span></label>
              <input value={buyer.name} onChange={e => onUpdateBuyer({ name: e.target.value })} placeholder="Customer / Company Name" />
            </div>
            <div className="form-group">
              <label className="form-label">GSTIN</label>
              <input value={buyer.gstin} onChange={e => onUpdateBuyer({ gstin: e.target.value.toUpperCase() })} placeholder="22BBBBB0000B1Z5" maxLength={15} style={{ fontFamily: 'var(--font-mono)' }} />
              <span className="form-help">Leave blank for B2C / unregistered buyers</span>
            </div>
          </div>
          <div className="form-group" style={{ marginBottom: 14 }}>
            <label className="form-label">Address</label>
            <textarea rows={2} value={buyer.address} onChange={e => onUpdateBuyer({ address: e.target.value })} placeholder="Customer's billing address" />
          </div>
          <div className="form-row cols-3">
            <div className="form-group">
              <label className="form-label">City</label>
              <input value={buyer.city} onChange={e => onUpdateBuyer({ city: e.target.value })} placeholder="Delhi" />
            </div>
            <div className="form-group">
              <label className="form-label">State <span className="req">*</span></label>
              <select value={buyer.state} onChange={e => onUpdateBuyer({ state: e.target.value })}>
                <option value="">Select State</option>
                {INDIAN_STATES.map(s => <option key={s.code} value={s.name}>{s.name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">PIN Code</label>
              <input value={buyer.pincode} onChange={e => onUpdateBuyer({ pincode: e.target.value })} placeholder="110001" maxLength={6} />
            </div>
          </div>
        </div>
      </div>

      {/* LINE ITEMS */}
      <div className="card">
        <div className="card-header">
          <div className="card-header-icon blue">📦</div>
          <div>
            <div className="card-title">Products & Services</div>
            <div className="card-subtitle">Add line items with HSN/SAC codes</div>
          </div>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table className="items-table">
            <thead>
              <tr>
                <th style={{ width: 28 }}>#</th>
                <th style={{ width: '28%' }}>Description <span style={{ color: 'var(--color-critical)' }}>*</span></th>
                <th style={{ width: '9%' }}>HSN/SAC</th>
                <th style={{ width: '7%' }}>Qty</th>
                <th style={{ width: '9%' }}>Unit</th>
                <th style={{ width: '12%' }}>Rate (₹)</th>
                <th style={{ width: '9%' }}>GST %</th>
                <th style={{ width: '12%', textAlign: 'right' }}>Amount</th>
                <th style={{ width: 36 }}></th>
              </tr>
            </thead>
            <tbody>
              {items.map((item, idx) => {
                const qty = parseFloat(item.qty) || 0;
                const rate = parseFloat(item.rate) || 0;
                const gst = parseFloat(item.gstRate) || 0;
                const taxable = qty * rate;
                const tax = taxable * gst / 100;
                const amount = taxable + tax;
                return (
                  <tr key={item.id}>
                    <td style={{ color: 'var(--color-text-subdued)', fontSize: '0.75rem', fontWeight: 700, textAlign: 'center' }}>{idx + 1}</td>
                    <td>
                      <input
                        value={item.description}
                        onChange={e => onUpdateItem(item.id, { description: e.target.value })}
                        placeholder="Product or service description"
                      />
                    </td>
                    <td>
                      <input
                        value={item.hsn}
                        onChange={e => onUpdateItem(item.id, { hsn: e.target.value })}
                        placeholder="HSN"
                        style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem' }}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        value={item.qty}
                        min={0}
                        onChange={e => onUpdateItem(item.id, { qty: e.target.value })}
                        placeholder="1"
                      />
                    </td>
                    <td>
                      <select value={item.unit} onChange={e => onUpdateItem(item.id, { unit: e.target.value })}>
                        {UNITS.map(u => <option key={u}>{u}</option>)}
                      </select>
                    </td>
                    <td>
                      <div className="input-wrap">
                        <span className="input-prefix">₹</span>
                        <input
                          type="number"
                          className="has-prefix"
                          value={item.rate}
                          min={0}
                          onChange={e => onUpdateItem(item.id, { rate: e.target.value })}
                          placeholder="0.00"
                        />
                      </div>
                    </td>
                    <td>
                      <select value={item.gstRate} onChange={e => onUpdateItem(item.id, { gstRate: e.target.value })}>
                        {GST_RATES.map(r => <option key={r} value={r}>{r}%</option>)}
                      </select>
                    </td>
                    <td>
                      <span className="item-amount">
                        ₹{new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2 }).format(amount)}
                      </span>
                    </td>
                    <td style={{ textAlign: 'center' }}>
                      <button
                        className="btn btn-plain btn-sm"
                        onClick={() => onRemoveItem(item.id)}
                        disabled={items.length === 1}
                        title="Remove item"
                        style={{ color: items.length === 1 ? 'var(--color-text-disabled)' : 'var(--color-critical)', padding: '4px 6px' }}
                      >
                        ✕
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <button className="add-item-btn" onClick={onAddItem}>
          <span style={{ fontSize: '1rem', lineHeight: 1 }}>+</span>
          Add Line Item
        </button>
      </div>

      {/* NOTES & DISCOUNT */}
      <div className="card">
        <div className="card-header">
          <div className="card-header-icon green">📝</div>
          <div>
            <div className="card-title">Notes & Additional</div>
            <div className="card-subtitle">Terms, conditions & discount</div>
          </div>
        </div>
        <div className="card-body">
          <div className="form-row cols-2">
            <div className="form-group">
              <label className="form-label">Notes / Terms & Conditions</label>
              <textarea
                rows={4}
                value={invoice.notes}
                onChange={e => onUpdateInvoice({ notes: e.target.value })}
                placeholder="Payment terms, delivery notes, thank you message..."
              />
            </div>
            <div className="form-group">
              <label className="form-label">Discount (₹)</label>
              <div className="input-wrap">
                <span className="input-prefix">₹</span>
                <input
                  type="number"
                  className="has-prefix"
                  value={invoice.discount}
                  min={0}
                  onChange={e => onUpdateInvoice({ discount: e.target.value })}
                  placeholder="0.00"
                />
              </div>
              <span className="form-help">Flat discount applied to invoice total</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
