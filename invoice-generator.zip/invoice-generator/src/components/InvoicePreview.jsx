import { formatINR, numberToWords } from '../utils/indianData.js';

export default function InvoicePreview({ data, totals }) {
  const { seller, buyer, invoice, items } = data;
  const isInterState = seller.state && buyer.state && seller.state !== buyer.state;

  return (
    <div style={{
      background: '#fff', border: '1px solid #e1e3e5', borderRadius: 12,
      padding: '40px', fontFamily: '"Plus Jakarta Sans", sans-serif',
      fontSize: '12px', color: '#1a1a1a', lineHeight: 1.5,
      boxShadow: '0 4px 16px rgba(0,0,0,0.08)'
    }}>
      {/* HEADER */}
      <div style={{ background: '#1a1a2e', margin: '-40px -40px 32px', padding: '28px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div style={{ fontSize: 22, fontWeight: 800, color: '#fff', letterSpacing: '-0.5px' }}>
            {seller.name || 'Your Business Name'}
          </div>
          <div style={{ color: 'rgba(200,200,220,0.9)', marginTop: 6, lineHeight: 1.7, fontSize: 11 }}>
            {[seller.address, seller.city, seller.state, seller.pincode].filter(Boolean).join(', ')}
            {seller.phone && <><br />📞 {seller.phone}</>}
            {seller.email && <>&nbsp;&nbsp;✉ {seller.email}</>}
            {seller.gstin && <><br /><span style={{ fontFamily: 'monospace', background: 'rgba(0,128,96,0.3)', padding: '1px 6px', borderRadius: 3 }}>GSTIN: {seller.gstin}</span></>}
            {seller.pan && <>&nbsp;&nbsp;<span style={{ fontFamily: 'monospace', background: 'rgba(255,255,255,0.1)', padding: '1px 6px', borderRadius: 3 }}>PAN: {seller.pan}</span></>}
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 26, fontWeight: 800, color: '#00d890', letterSpacing: '3px' }}>TAX INVOICE</div>
          <div style={{ color: 'rgba(200,200,220,0.85)', marginTop: 8, lineHeight: 1.9, fontSize: 11 }}>
            <div><span style={{ color: 'rgba(200,200,220,0.6)' }}>Invoice No: </span><strong style={{ color: '#fff', fontFamily: 'monospace' }}>{invoice.number}</strong></div>
            <div><span style={{ color: 'rgba(200,200,220,0.6)' }}>Date: </span><strong style={{ color: '#fff' }}>{invoice.date}</strong></div>
            {invoice.dueDate && <div><span style={{ color: 'rgba(200,200,220,0.6)' }}>Due Date: </span><strong style={{ color: '#ffd060' }}>{invoice.dueDate}</strong></div>}
          </div>
        </div>
      </div>

      {/* PARTIES */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 24 }}>
        {/* Bill To */}
        <div style={{ background: '#f8f9fa', borderRadius: 8, padding: 16, border: '1px solid #e5e7eb' }}>
          <div style={{ fontSize: 9, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '1px', color: '#008060', marginBottom: 8 }}>Bill To</div>
          <div style={{ fontSize: 15, fontWeight: 800, color: '#1a1a2e', marginBottom: 4 }}>{buyer.name || 'Customer Name'}</div>
          <div style={{ color: '#555', lineHeight: 1.8, fontSize: 11 }}>
            {buyer.address && <div>{buyer.address}</div>}
            {(buyer.city || buyer.state) && <div>{[buyer.city, buyer.state, buyer.pincode].filter(Boolean).join(', ')}</div>}
            {buyer.gstin && <div style={{ marginTop: 4 }}><span style={{ fontFamily: 'monospace', background: '#e3f1ed', color: '#008060', padding: '2px 6px', borderRadius: 3, fontSize: 10 }}>GSTIN: {buyer.gstin}</span></div>}
          </div>
        </div>

        {/* Invoice Info */}
        <div style={{ background: '#f8f9fa', borderRadius: 8, padding: 16, border: '1px solid #e5e7eb' }}>
          <div style={{ fontSize: 9, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '1px', color: '#008060', marginBottom: 8 }}>Invoice Details</div>
          {[
            ['Place of Supply', invoice.placeOfSupply],
            ['Payment Terms', invoice.paymentTerms],
            ['PO Number', invoice.poNumber],
            ['Tax Type', isInterState ? 'IGST (Inter-state)' : 'CGST + SGST (Intra-state)'],
          ].filter(([, v]) => v).map(([label, value]) => (
            <div key={label} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5, fontSize: 11 }}>
              <span style={{ color: '#777' }}>{label}:</span>
              <span style={{ fontWeight: 600, color: '#1a1a2e' }}>{value}</span>
            </div>
          ))}
        </div>
      </div>

      {/* ITEMS TABLE */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: 20, fontSize: 11 }}>
        <thead>
          <tr style={{ background: '#1a1a2e' }}>
            {['#', 'Description', 'HSN/SAC', 'Qty', 'Unit', 'Rate (₹)', isInterState ? 'IGST%' : 'GST%',
              isInterState ? 'IGST (₹)' : 'CGST (₹)', isInterState ? 'Amount (₹)' : 'SGST (₹)', ...(!isInterState ? ['Amount (₹)'] : [])
            ].map((h, i) => (
              <th key={i} style={{
                color: '#fff', padding: '8px 8px', textAlign: i === 0 ? 'center' : i >= 5 ? 'right' : 'left',
                fontWeight: 700, fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.4px'
              }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {items.map((item, idx) => {
            const qty = parseFloat(item.qty) || 0;
            const rate = parseFloat(item.rate) || 0;
            const gst = parseFloat(item.gstRate) || 0;
            const taxable = qty * rate;
            const tax = taxable * gst / 100;
            const amount = taxable + tax;
            const half = tax / 2;
            const bg = idx % 2 === 1 ? '#fafafa' : '#fff';
            return (
              <tr key={item.id} style={{ background: bg }}>
                <td style={{ padding: '8px 8px', textAlign: 'center', color: '#888', fontWeight: 700 }}>{idx + 1}</td>
                <td style={{ padding: '8px 8px', fontWeight: 600, color: '#1a1a2e' }}>{item.description || '—'}<br />{item.hsn && <span style={{ fontSize: 9, color: '#888', fontFamily: 'monospace' }}>HSN: {item.hsn}</span>}</td>
                <td style={{ padding: '8px 8px', textAlign: 'center', fontFamily: 'monospace', color: '#555' }}>{item.hsn || '—'}</td>
                <td style={{ padding: '8px 8px', textAlign: 'right' }}>{qty}</td>
                <td style={{ padding: '8px 8px', textAlign: 'center', color: '#555' }}>{item.unit}</td>
                <td style={{ padding: '8px 8px', textAlign: 'right', fontFamily: 'monospace' }}>{formatINR(rate)}</td>
                <td style={{ padding: '8px 8px', textAlign: 'right', color: '#555' }}>{gst}%</td>
                <td style={{ padding: '8px 8px', textAlign: 'right', fontFamily: 'monospace' }}>{formatINR(isInterState ? tax : half)}</td>
                {!isInterState && <td style={{ padding: '8px 8px', textAlign: 'right', fontFamily: 'monospace' }}>{formatINR(half)}</td>}
                <td style={{ padding: '8px 8px', textAlign: 'right', fontFamily: 'monospace', fontWeight: 700, color: '#1a1a2e' }}>₹{formatINR(amount)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>

      {/* TOTALS + NOTES */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 24, marginBottom: 20 }}>
        {/* Notes */}
        <div style={{ flex: 1 }}>
          {invoice.notes && (
            <>
              <div style={{ fontSize: 9, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '1px', color: '#888', marginBottom: 6 }}>Notes & Terms</div>
              <div style={{ fontSize: 11, color: '#444', lineHeight: 1.7, whiteSpace: 'pre-line' }}>{invoice.notes}</div>
            </>
          )}
          {(seller.bankName || seller.accountNo) && (
            <div style={{ marginTop: 16 }}>
              <div style={{ fontSize: 9, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '1px', color: '#888', marginBottom: 6 }}>Bank Details</div>
              <div style={{ fontSize: 11, color: '#444', lineHeight: 1.8 }}>
                {seller.bankName && <div>Bank: <strong>{seller.bankName}</strong></div>}
                {seller.accountNo && <div>Account No: <strong style={{ fontFamily: 'monospace' }}>{seller.accountNo}</strong></div>}
                {seller.ifsc && <div>IFSC: <strong style={{ fontFamily: 'monospace' }}>{seller.ifsc}</strong></div>}
              </div>
            </div>
          )}
        </div>

        {/* Totals Box */}
        <div style={{ width: 240, border: '1px solid #e5e7eb', borderRadius: 8, overflow: 'hidden', flexShrink: 0 }}>
          {[
            ['Subtotal', `₹${formatINR(totals.subtotal)}`],
            ...(isInterState
              ? [['IGST', `₹${formatINR(totals.totalTax)}`]]
              : [['CGST', `₹${formatINR(totals.totalTax / 2)}`], ['SGST', `₹${formatINR(totals.totalTax / 2)}`]]),
            ...(totals.discount > 0 ? [['Discount', `-₹${formatINR(totals.discount)}`]] : []),
          ].map(([label, value]) => (
            <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '7px 14px', borderBottom: '1px solid #f0f0f0', fontSize: 11 }}>
              <span style={{ color: '#666' }}>{label}</span>
              <span style={{ fontFamily: 'monospace', fontWeight: 600 }}>{value}</span>
            </div>
          ))}
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 14px', background: '#1a1a2e', fontSize: 13, fontWeight: 800 }}>
            <span style={{ color: '#fff' }}>Grand Total</span>
            <span style={{ color: '#00d890', fontFamily: 'monospace' }}>₹{formatINR(totals.grandTotal)}</span>
          </div>
        </div>
      </div>

      {/* Amount in Words */}
      <div style={{ background: '#e3f1ed', borderRadius: 6, padding: '10px 16px', fontSize: 11, color: '#005e46', fontWeight: 600, marginBottom: 24 }}>
        <span style={{ color: '#008060', marginRight: 6 }}>Amount in Words:</span>
        {numberToWords(totals.grandTotal)}
      </div>

      {/* FOOTER */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', paddingTop: 16, borderTop: '1px solid #e5e7eb' }}>
        <div style={{ fontSize: 10, color: '#888' }}>
          <div style={{ fontWeight: 700, marginBottom: 2 }}>Declaration</div>
          <div>We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.</div>
        </div>
        <div style={{ textAlign: 'right', flexShrink: 0, marginLeft: 40 }}>
          <div style={{ fontSize: 11, color: '#444', marginBottom: 4 }}>For <strong>{seller.name || 'Company Name'}</strong></div>
          <div style={{ height: 40 }}></div>
          <div style={{ borderTop: '1px solid #1a1a2e', paddingTop: 6, fontSize: 10, color: '#555', fontWeight: 600 }}>Authorised Signatory</div>
        </div>
      </div>

      <div style={{ marginTop: 20, paddingTop: 12, borderTop: '1px solid #f0f0f0', textAlign: 'center', fontSize: 9, color: '#aaa' }}>
        This is a computer-generated invoice. Generated using BillKaro — Indian GST Invoice Generator
      </div>
    </div>
  );
}
