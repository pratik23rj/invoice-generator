import React, { useState } from 'react';
import {
  AppProvider,
  Page,
  Card,
  FormLayout,
  TextField,
  Select,
  Button,
  Banner,
  Divider,
  Text,
  InlineStack,
  BlockStack,
} from '@shopify/polaris';
import { ExportIcon, ViewIcon, PlusCircleIcon, DeleteIcon } from '@shopify/polaris-icons';
import enTranslations from '@shopify/polaris/locales/en.json';
import { generateInvoicePDF } from './generatePDF';

const TAX_RATES = [
  { label: '0% (Exempt / Nil Rated)', value: '0' },
  { label: '5% GST', value: '5' },
  { label: '12% GST', value: '12' },
  { label: '18% GST', value: '18' },
  { label: '28% GST', value: '28' },
];

const INDIAN_STATES = [
  'Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat',
  'Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh',
  'Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab',
  'Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh',
  'Uttarakhand','West Bengal','Delhi','Jammu & Kashmir','Ladakh','Chandigarh',
  'Puducherry','Lakshadweep','Andaman & Nicobar Islands','Dadra & Nagar Haveli',
].map(s => ({ label: s, value: s }));

const UNITS = ['Nos', 'Kg', 'Gm', 'Ltr', 'Mtr', 'Sq.Ft', 'Sq.Mtr', 'Box', 'Pcs', 'Set', 'Hrs', 'Days', 'Month'];

const emptyItem = () => ({
  id: Date.now() + Math.random(),
  description: '', hsn: '', qty: '1', unit: 'Nos', rate: '', taxRate: '18',
});

const today = () => new Date().toISOString().split('T')[0];
const dueIn30 = () => { const d = new Date(); d.setDate(d.getDate() + 30); return d.toISOString().split('T')[0]; };

function formatINR(num) {
  if (!num || isNaN(num)) return '0.00';
  return new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(num);
}

export default function App() {
  const [activeTab, setActiveTab] = useState(0);
  const [showPreview, setShowPreview] = useState(false);
  const [pdfSuccess, setPdfSuccess] = useState(false);

  const [seller, setSeller] = useState({
    businessName: '', address: '', city: '', state: 'Maharashtra',
    pincode: '', gstin: '', pan: '', email: '', phone: '',
  });
  const [buyer, setBuyer] = useState({
    name: '', address: '', city: '', state: 'Maharashtra',
    pincode: '', gstin: '', phone: '', email: '',
  });
  const [invoice, setInvoice] = useState({
    invoiceNumber: 'INV-001', date: today(), dueDate: dueIn30(), poNumber: '',
  });
  const [items, setItems] = useState([emptyItem()]);
  const [taxType, setTaxType] = useState('cgst');
  const [discount, setDiscount] = useState('');
  const [notes, setNotes] = useState('');
  const [terms, setTerms] = useState('Payment due within 30 days. Late payments attract 18% interest per annum.');
  const [bankDetails, setBankDetails] = useState({
    bankName: '', accountNumber: '', ifsc: '', branch: '', accountName: '',
  });

  const updateSeller = (k, v) => setSeller(p => ({ ...p, [k]: v }));
  const updateBuyer = (k, v) => setBuyer(p => ({ ...p, [k]: v }));
  const updateInvoice = (k, v) => setInvoice(p => ({ ...p, [k]: v }));
  const updateBank = (k, v) => setBankDetails(p => ({ ...p, [k]: v }));
  const updateItem = (id, key, value) => setItems(prev => prev.map(it => it.id === id ? { ...it, [key]: value } : it));
  const addItem = () => setItems(prev => [...prev, emptyItem()]);
  const removeItem = (id) => setItems(prev => prev.filter(it => it.id !== id));

  const subtotal = items.reduce((s, it) => s + (parseFloat(it.qty) || 0) * (parseFloat(it.rate) || 0), 0);
  const totalTax = items.reduce((s, it) => {
    const base = (parseFloat(it.qty) || 0) * (parseFloat(it.rate) || 0);
    return s + base * (parseFloat(it.taxRate) || 0) / 100;
  }, 0);
  const discountAmt = parseFloat(discount) || 0;
  const grandTotal = subtotal + totalTax - discountAmt;

  const handleDownloadPDF = () => {
    generateInvoicePDF({ seller, buyer, invoice, items, taxType, discount, notes, terms, bankDetails });
    setPdfSuccess(true);
    setTimeout(() => setPdfSuccess(false), 4000);
  };

  const tabs = [
    { label: '🏢 Your Business', step: 0 },
    { label: '👤 Customer', step: 1 },
    { label: '📋 Invoice Info', step: 2 },
    { label: '📦 Items', step: 3 },
    { label: '🏦 Bank & Notes', step: 4 },
  ];

  const statesDiffer = seller.state && buyer.state && seller.state !== buyer.state;

  return (
    <AppProvider i18n={enTranslations}>
      {/* Header */}
      <div className="app-header">
        <div className="app-header-inner">
          <div className="app-logo">
            <div className="app-logo-icon">🧾</div>
            <div className="app-logo-text">
              <h1>BillMatic</h1>
              <p>GST Invoice Generator for India</p>
            </div>
          </div>
          <span className="header-badge">🇮🇳 India GST Ready</span>
        </div>
      </div>

      <div className="app-main">
        {/* Success Banner */}
        {pdfSuccess && (
          <div style={{ marginBottom: 16 }}>
            <Banner title="Invoice downloaded successfully!" tone="success">
              <p>Your PDF invoice has been saved to your Downloads folder.</p>
            </Banner>
          </div>
        )}

        {/* Action Bar */}
        <div className="action-bar">
          <div className="action-bar-text">
            <h3>Create Professional GST Invoice</h3>
            <p>Fill in the details across all tabs, then preview and download your invoice as PDF.</p>
          </div>
          <div className="action-bar-buttons">
            <Button onClick={() => setShowPreview(!showPreview)} icon={ViewIcon} variant="plain">
              {showPreview ? 'Hide Preview' : 'Live Preview'}
            </Button>
            <Button onClick={handleDownloadPDF} icon={ExportIcon} variant="primary" tone="success">
              Download PDF
            </Button>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: showPreview ? '1fr 1fr' : '1fr', gap: '20px', alignItems: 'start' }}>
          {/* ─── Form Panel ─── */}
          <div>
            <div className="step-tabs">
              {tabs.map(t => (
                <button key={t.step} className={`step-tab ${activeTab === t.step ? 'active' : ''}`} onClick={() => setActiveTab(t.step)}>
                  {t.label}
                </button>
              ))}
            </div>

            {/* ── Tab 0: Seller ── */}
            {activeTab === 0 && (
              <Card>
                <BlockStack gap="400">
                  <div className="section-header">
                    <span className="section-dot"></span>
                    <span className="section-title">Your Business Details</span>
                  </div>
                  <FormLayout>
                    <TextField label="Business / Company Name *" value={seller.businessName}
                      onChange={v => updateSeller('businessName', v)} placeholder="e.g. Sharma Enterprises Pvt. Ltd." autoComplete="off" />
                    <TextField label="Address" value={seller.address}
                      onChange={v => updateSeller('address', v)} placeholder="Street address, Area" autoComplete="off" multiline={2} />
                    <FormLayout.Group>
                      <TextField label="City" value={seller.city} onChange={v => updateSeller('city', v)} placeholder="Mumbai" autoComplete="off" />
                      <Select label="State" options={[{ label: 'Select State', value: '' }, ...INDIAN_STATES]} value={seller.state} onChange={v => updateSeller('state', v)} />
                      <TextField label="PIN Code" value={seller.pincode} onChange={v => updateSeller('pincode', v)} placeholder="400001" autoComplete="off" maxLength={6} />
                    </FormLayout.Group>
                    <Divider />
                    <Text variant="headingSm" tone="subdued">GST & Tax Information</Text>
                    <FormLayout.Group>
                      <TextField label="GSTIN" value={seller.gstin} onChange={v => updateSeller('gstin', v.toUpperCase())}
                        placeholder="22AAAAA0000A1Z5" helpText="15-digit GST Identification Number" autoComplete="off" />
                      <TextField label="PAN Number" value={seller.pan} onChange={v => updateSeller('pan', v.toUpperCase())}
                        placeholder="ABCDE1234F" autoComplete="off" />
                    </FormLayout.Group>
                    <Divider />
                    <Text variant="headingSm" tone="subdued">Contact Information</Text>
                    <FormLayout.Group>
                      <TextField label="Email" value={seller.email} type="email" onChange={v => updateSeller('email', v)} placeholder="info@yourbusiness.com" autoComplete="off" />
                      <TextField label="Phone" value={seller.phone} type="tel" onChange={v => updateSeller('phone', v)} placeholder="+91 98765 43210" autoComplete="off" />
                    </FormLayout.Group>
                  </FormLayout>
                  <div style={{ marginTop: 8 }}>
                    <Button variant="primary" tone="success" onClick={() => setActiveTab(1)}>Next: Customer Details →</Button>
                  </div>
                </BlockStack>
              </Card>
            )}

            {/* ── Tab 1: Buyer ── */}
            {activeTab === 1 && (
              <Card>
                <BlockStack gap="400">
                  <div className="section-header"><span className="section-dot"></span><span className="section-title">Customer / Bill To</span></div>
                  <FormLayout>
                    <TextField label="Customer Name / Company *" value={buyer.name} onChange={v => updateBuyer('name', v)} placeholder="e.g. Patel Industries" autoComplete="off" />
                    <TextField label="Billing Address" value={buyer.address} onChange={v => updateBuyer('address', v)} placeholder="Street address, Area" autoComplete="off" multiline={2} />
                    <FormLayout.Group>
                      <TextField label="City" value={buyer.city} onChange={v => updateBuyer('city', v)} placeholder="Delhi" autoComplete="off" />
                      <Select label="State" options={[{ label: 'Select State', value: '' }, ...INDIAN_STATES]} value={buyer.state} onChange={v => updateBuyer('state', v)} />
                      <TextField label="PIN Code" value={buyer.pincode} onChange={v => updateBuyer('pincode', v)} placeholder="110001" autoComplete="off" maxLength={6} />
                    </FormLayout.Group>
                    <Divider />
                    <TextField label="Customer GSTIN (if registered)" value={buyer.gstin} onChange={v => updateBuyer('gstin', v.toUpperCase())}
                      placeholder="22AAAAA0000A1Z5" helpText="Required for B2B GST invoices" autoComplete="off" />
                    <FormLayout.Group>
                      <TextField label="Phone" value={buyer.phone} onChange={v => updateBuyer('phone', v)} placeholder="+91 98765 43210" autoComplete="off" />
                      <TextField label="Email" value={buyer.email} type="email" onChange={v => updateBuyer('email', v)} placeholder="customer@email.com" autoComplete="off" />
                    </FormLayout.Group>
                  </FormLayout>
                  <InlineStack gap="200">
                    <Button onClick={() => setActiveTab(0)}>← Back</Button>
                    <Button variant="primary" tone="success" onClick={() => setActiveTab(2)}>Next: Invoice Info →</Button>
                  </InlineStack>
                </BlockStack>
              </Card>
            )}

            {/* ── Tab 2: Invoice Details ── */}
            {activeTab === 2 && (
              <Card>
                <BlockStack gap="400">
                  <div className="section-header"><span className="section-dot"></span><span className="section-title">Invoice Information</span></div>
                  <FormLayout>
                    <FormLayout.Group>
                      <TextField label="Invoice Number *" value={invoice.invoiceNumber} onChange={v => updateInvoice('invoiceNumber', v)} placeholder="INV-001" autoComplete="off" />
                      <TextField label="Invoice Date *" value={invoice.date} type="date" onChange={v => updateInvoice('date', v)} />
                      <TextField label="Due Date" value={invoice.dueDate} type="date" onChange={v => updateInvoice('dueDate', v)} />
                    </FormLayout.Group>
                    <TextField label="PO Number / Reference (Optional)" value={invoice.poNumber} onChange={v => updateInvoice('poNumber', v)} placeholder="PO-2024-001" autoComplete="off" />
                    <Divider />
                    <div className="section-header" style={{ marginBottom: 0 }}>
                      <span className="section-dot"></span><span className="section-title">GST Tax Type</span>
                    </div>
                    <div className="tax-info-banner">
                      <span>💡</span>
                      <span>Choose <strong>CGST + SGST</strong> for same-state sales. Choose <strong>IGST</strong> for cross-state sales.</span>
                    </div>
                    <Select
                      label="Tax Structure"
                      options={[
                        { label: '🏘️ CGST + SGST — Intrastate (Same State)', value: 'cgst' },
                        { label: '🗺️ IGST — Interstate (Different State)', value: 'igst' },
                      ]}
                      value={taxType}
                      onChange={setTaxType}
                    />
                    {statesDiffer && (
                      <Banner tone="warning">
                        Seller state ({seller.state}) and Buyer state ({buyer.state}) differ — you should use <strong>IGST</strong>.
                      </Banner>
                    )}
                    <Divider />
                    <TextField label="Global Discount Amount (₹)" value={discount} onChange={setDiscount}
                      placeholder="0.00" type="number" helpText="Flat discount subtracted from grand total" autoComplete="off" />
                  </FormLayout>
                  <InlineStack gap="200">
                    <Button onClick={() => setActiveTab(1)}>← Back</Button>
                    <Button variant="primary" tone="success" onClick={() => setActiveTab(3)}>Next: Add Items →</Button>
                  </InlineStack>
                </BlockStack>
              </Card>
            )}

            {/* ── Tab 3: Line Items ── */}
            {activeTab === 3 && (
              <Card>
                <BlockStack gap="400">
                  <div className="section-header"><span className="section-dot"></span><span className="section-title">Products & Services</span></div>
                  <div className="items-table-wrap">
                    <table className="items-editor-table">
                      <thead>
                        <tr>
                          <th style={{ minWidth: 170 }}>Description *</th>
                          <th style={{ width: 80 }}>HSN/SAC</th>
                          <th style={{ width: 60 }}>Qty</th>
                          <th style={{ width: 70 }}>Unit</th>
                          <th style={{ width: 95 }}>Rate (₹)</th>
                          <th style={{ width: 120 }}>Tax Rate</th>
                          <th style={{ width: 95, textAlign: 'right' }}>Amount (₹)</th>
                          <th style={{ width: 36 }}></th>
                        </tr>
                      </thead>
                      <tbody>
                        {items.map(item => {
                          const base = (parseFloat(item.qty) || 0) * (parseFloat(item.rate) || 0);
                          const tax = base * (parseFloat(item.taxRate) || 0) / 100;
                          const amount = base + tax;
                          const inputStyle = { width: '100%', border: '1px solid #e5e7eb', borderRadius: 6, padding: '6px 8px', fontFamily: 'inherit', fontSize: 13, outline: 'none', boxSizing: 'border-box' };
                          const selectStyle = { ...inputStyle, background: 'white', cursor: 'pointer' };
                          return (
                            <tr key={item.id}>
                              <td><input style={inputStyle} value={item.description} onChange={e => updateItem(item.id, 'description', e.target.value)} placeholder="Item description..." /></td>
                              <td><input style={inputStyle} value={item.hsn} onChange={e => updateItem(item.id, 'hsn', e.target.value)} placeholder="e.g. 8471" /></td>
                              <td><input type="number" style={inputStyle} value={item.qty} onChange={e => updateItem(item.id, 'qty', e.target.value)} min="0" /></td>
                              <td>
                                <select style={selectStyle} value={item.unit} onChange={e => updateItem(item.id, 'unit', e.target.value)}>
                                  {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                                </select>
                              </td>
                              <td><input type="number" style={inputStyle} value={item.rate} onChange={e => updateItem(item.id, 'rate', e.target.value)} placeholder="0.00" min="0" step="0.01" /></td>
                              <td>
                                <select style={selectStyle} value={item.taxRate} onChange={e => updateItem(item.id, 'taxRate', e.target.value)}>
                                  {TAX_RATES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
                                </select>
                              </td>
                              <td style={{ textAlign: 'right' }}><span className="item-row-amount">₹{formatINR(amount)}</span></td>
                              <td>
                                <button className="delete-item-btn" onClick={() => removeItem(item.id)} title="Remove item">
                                  <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                                  </svg>
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 16, flexWrap: 'wrap' }}>
                    <Button onClick={addItem} icon={PlusCircleIcon} variant="plain" tone="success">Add Another Item</Button>
                    <div style={{ textAlign: 'right', background: '#f8fffe', borderRadius: 10, padding: '12px 16px', border: '1px solid #e3f5f0', minWidth: 220 }}>
                      <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 4 }}>Subtotal: <strong style={{ color: '#111' }}>₹{formatINR(subtotal)}</strong></div>
                      {taxType === 'igst'
                        ? <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 4 }}>IGST: <strong style={{ color: '#111' }}>₹{formatINR(totalTax)}</strong></div>
                        : <>
                            <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 2 }}>CGST: <strong style={{ color: '#111' }}>₹{formatINR(totalTax / 2)}</strong></div>
                            <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 4 }}>SGST: <strong style={{ color: '#111' }}>₹{formatINR(totalTax / 2)}</strong></div>
                          </>
                      }
                      {discountAmt > 0 && <div style={{ fontSize: 12, color: '#dc2626', marginBottom: 4 }}>Discount: <strong>-₹{formatINR(discountAmt)}</strong></div>}
                      <div style={{ borderTop: '2px solid #004c3f', paddingTop: 8, marginTop: 4, fontSize: 16, fontWeight: 800, color: '#004c3f' }}>
                        Grand Total: ₹{formatINR(grandTotal)}
                      </div>
                    </div>
                  </div>

                  <InlineStack gap="200">
                    <Button onClick={() => setActiveTab(2)}>← Back</Button>
                    <Button variant="primary" tone="success" onClick={() => setActiveTab(4)}>Next: Bank & Notes →</Button>
                  </InlineStack>
                </BlockStack>
              </Card>
            )}

            {/* ── Tab 4: Bank + Notes ── */}
            {activeTab === 4 && (
              <Card>
                <BlockStack gap="400">
                  <div className="section-header"><span className="section-dot"></span><span className="section-title">Bank Details (Optional)</span></div>
                  <FormLayout>
                    <FormLayout.Group>
                      <TextField label="Account Holder Name" value={bankDetails.accountName} onChange={v => updateBank('accountName', v)} placeholder="Business Legal Name" autoComplete="off" />
                      <TextField label="Bank Name" value={bankDetails.bankName} onChange={v => updateBank('bankName', v)} placeholder="State Bank of India" autoComplete="off" />
                    </FormLayout.Group>
                    <FormLayout.Group>
                      <TextField label="Account Number" value={bankDetails.accountNumber} onChange={v => updateBank('accountNumber', v)} placeholder="XXXXXXXXXXXX" autoComplete="off" />
                      <TextField label="IFSC Code" value={bankDetails.ifsc} onChange={v => updateBank('ifsc', v.toUpperCase())} placeholder="SBIN0001234" autoComplete="off" />
                    </FormLayout.Group>
                    <TextField label="Branch" value={bankDetails.branch} onChange={v => updateBank('branch', v)} placeholder="Main Branch, Mumbai" autoComplete="off" />
                  </FormLayout>
                  <Divider />
                  <div className="section-header"><span className="section-dot"></span><span className="section-title">Notes & Terms</span></div>
                  <FormLayout>
                    <TextField label="Notes (printed on invoice)" value={notes} multiline={3} onChange={setNotes} placeholder="e.g. Thank you for your business!" autoComplete="off" />
                    <TextField label="Terms & Conditions" value={terms} multiline={3} onChange={setTerms} placeholder="e.g. Payment due within 30 days." autoComplete="off" />
                  </FormLayout>

                  {/* Summary Box */}
                  <div style={{ background: 'linear-gradient(135deg,#f0fdf9,#e3f5f0)', borderRadius: 12, padding: '16px 20px', border: '1px solid #a7f3d0' }}>
                    <div style={{ fontWeight: 700, fontSize: 13, color: '#004c3f', marginBottom: 10 }}>📊 Invoice Summary</div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px 24px', fontSize: 13, color: '#374151' }}>
                      <div>Invoice #: <strong>{invoice.invoiceNumber}</strong></div>
                      <div>Date: <strong>{invoice.date}</strong></div>
                      <div>Customer: <strong>{buyer.name || '—'}</strong></div>
                      <div>Items: <strong>{items.length}</strong></div>
                      <div>Tax Type: <strong>{taxType === 'igst' ? 'IGST' : 'CGST + SGST'}</strong></div>
                      <div style={{ fontSize: 15, fontWeight: 800, color: '#004c3f' }}>Total: ₹{formatINR(grandTotal)}</div>
                    </div>
                  </div>

                  <InlineStack gap="200">
                    <Button onClick={() => setActiveTab(3)}>← Back</Button>
                    <Button variant="primary" tone="success" size="large" icon={ExportIcon} onClick={handleDownloadPDF}>
                      Download Invoice PDF
                    </Button>
                  </InlineStack>
                </BlockStack>
              </Card>
            )}
          </div>

          {/* ─── Live Preview Panel ─── */}
          {showPreview && (
            <div>
              <div className="section-header"><span className="section-dot"></span><span className="section-title">Live Preview</span></div>
              <div className="preview-card">
                <div className="invoice-watermark">BillMatic</div>
                <div className="invoice-preview-header">
                  <div>
                    <p className="invoice-company-name">{seller.businessName || 'Your Business Name'}</p>
                    <div className="invoice-company-details">
                      {[seller.address, seller.city, seller.state, seller.pincode].filter(Boolean).join(', ') || '123 Business Street, City, State'}
                      <br />
                      {seller.gstin && <span>GSTIN: {seller.gstin} &nbsp;|&nbsp; </span>}
                      {seller.pan && <span>PAN: {seller.pan}<br /></span>}
                      {seller.email && <span>{seller.email}</span>}
                      {seller.phone && <span> | {seller.phone}</span>}
                    </div>
                  </div>
                  <div className="invoice-badge">
                    <span className="invoice-badge-title">INVOICE</span>
                    <span className="invoice-badge-num">#{invoice.invoiceNumber || 'INV-001'}</span>
                    <span className="invoice-badge-num" style={{ fontSize: 11, marginTop: 4 }}>{invoice.date}</span>
                  </div>
                </div>

                <div className="invoice-parties">
                  <div className="invoice-party">
                    <h4>Bill To</h4>
                    <p>
                      <strong>{buyer.name || 'Customer Name'}</strong><br />
                      {[buyer.address, buyer.city, buyer.state, buyer.pincode].filter(Boolean).join(', ') || 'Customer Address'}
                      {buyer.gstin && <><br />GSTIN: {buyer.gstin}</>}
                      {buyer.phone && <><br />Ph: {buyer.phone}</>}
                    </p>
                  </div>
                  <div className="invoice-party">
                    <h4>Invoice Details</h4>
                    <p>
                      <strong>Invoice #:</strong> {invoice.invoiceNumber}<br />
                      <strong>Date:</strong> {invoice.date}<br />
                      <strong>Due:</strong> {invoice.dueDate || 'On Receipt'}<br />
                      <strong>Tax:</strong> {taxType === 'igst' ? 'IGST (Interstate)' : 'CGST + SGST (Intrastate)'}
                      {invoice.poNumber && <><br /><strong>PO #:</strong> {invoice.poNumber}</>}
                    </p>
                  </div>
                </div>

                <table className="preview-table">
                  <thead>
                    <tr>
                      <th>#</th><th>Description</th><th>HSN</th><th>Qty</th><th>Rate</th><th>Tax</th><th>Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((item, idx) => {
                      const base = (parseFloat(item.qty) || 0) * (parseFloat(item.rate) || 0);
                      const tax = base * (parseFloat(item.taxRate) || 0) / 100;
                      return (
                        <tr key={item.id}>
                          <td>{idx + 1}</td>
                          <td>{item.description || '—'}</td>
                          <td>{item.hsn || '—'}</td>
                          <td>{item.qty} {item.unit}</td>
                          <td>₹{formatINR(parseFloat(item.rate) || 0)}</td>
                          <td>{item.taxRate}%</td>
                          <td>₹{formatINR(base + tax)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>

                <div className="totals-grid">
                  <div className="totals-box">
                    <div className="totals-row"><span>Subtotal</span><span>₹{formatINR(subtotal)}</span></div>
                    {taxType === 'igst'
                      ? <div className="totals-row"><span>IGST</span><span>₹{formatINR(totalTax)}</span></div>
                      : <>
                          <div className="totals-row"><span>CGST</span><span>₹{formatINR(totalTax / 2)}</span></div>
                          <div className="totals-row"><span>SGST</span><span>₹{formatINR(totalTax / 2)}</span></div>
                        </>
                    }
                    {discountAmt > 0 && <div className="totals-row" style={{ color: '#dc2626' }}><span>Discount</span><span>-₹{formatINR(discountAmt)}</span></div>}
                    <div className="totals-row total-final"><span>Grand Total</span><span>₹{formatINR(grandTotal)}</span></div>
                  </div>
                </div>

                {(notes || terms || bankDetails.bankName) && (
                  <div className="notes-section">
                    {bankDetails.bankName && (
                      <p><strong>Bank:</strong> {bankDetails.bankName} | A/C: {bankDetails.accountNumber} | IFSC: {bankDetails.ifsc}</p>
                    )}
                    {notes && <p><strong>Notes:</strong> {notes}</p>}
                    {terms && <p><strong>Terms:</strong> {terms}</p>}
                  </div>
                )}
              </div>
              <div style={{ marginTop: 12, textAlign: 'center' }}>
                <Button variant="primary" tone="success" size="large" icon={ExportIcon} onClick={handleDownloadPDF}>
                  Download Invoice PDF
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </AppProvider>
  );
}
