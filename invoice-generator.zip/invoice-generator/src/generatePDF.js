import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

function numberToWords(num) {
  const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function convert(n) {
    if (n < 20) return ones[n];
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + ones[n % 10] : '');
    if (n < 1000) return ones[Math.floor(n / 100)] + ' Hundred' + (n % 100 !== 0 ? ' ' + convert(n % 100) : '');
    if (n < 100000) return convert(Math.floor(n / 1000)) + ' Thousand' + (n % 1000 !== 0 ? ' ' + convert(n % 1000) : '');
    if (n < 10000000) return convert(Math.floor(n / 100000)) + ' Lakh' + (n % 100000 !== 0 ? ' ' + convert(n % 100000) : '');
    return convert(Math.floor(n / 10000000)) + ' Crore' + (n % 10000000 !== 0 ? ' ' + convert(n % 10000000) : '');
  }

  if (num === 0) return 'Zero';
  const rupees = Math.floor(num);
  const paise = Math.round((num - rupees) * 100);
  let result = convert(rupees) + ' Rupees';
  if (paise > 0) result += ' and ' + convert(paise) + ' Paise';
  return result + ' Only';
}

export function generateInvoicePDF(data) {
  const { seller, buyer, invoice, items, taxType, discount, notes, terms, bankDetails } = data;

  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const pageW = 210;
  const margin = 15;
  const contentW = pageW - margin * 2;

  // Header Background
  doc.setFillColor(0, 76, 63);
  doc.rect(0, 0, pageW, 42, 'F');

  // Accent strip
  doc.setFillColor(0, 167, 111);
  doc.rect(0, 40, pageW, 3, 'F');

  // Company Name
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(20);
  doc.setTextColor(255, 255, 255);
  doc.text(seller.businessName || 'Your Business', margin, 17);

  // Seller details
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(200, 240, 230);
  const sellerAddr = [seller.address, seller.city, seller.state, seller.pincode].filter(Boolean).join(', ');
  doc.text(sellerAddr || '', margin, 24);
  if (seller.gstin) doc.text(`GSTIN: ${seller.gstin}`, margin, 29);
  if (seller.pan) doc.text(`PAN: ${seller.pan}`, margin, 33);
  if (seller.email) doc.text(`Email: ${seller.email}  |  Phone: ${seller.phone || ''}`, margin, 37);

  // INVOICE badge (right side)
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(22);
  doc.setTextColor(255, 255, 255);
  doc.text('INVOICE', pageW - margin, 17, { align: 'right' });
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(200, 240, 230);
  doc.text(`#${invoice.invoiceNumber || 'INV-001'}`, pageW - margin, 24, { align: 'right' });
  doc.text(`Date: ${invoice.date || ''}`, pageW - margin, 30, { align: 'right' });
  if (invoice.dueDate) doc.text(`Due: ${invoice.dueDate}`, pageW - margin, 35, { align: 'right' });

  let y = 52;

  // Bill To / Ship To boxes
  doc.setFillColor(248, 255, 254);
  doc.roundedRect(margin, y, contentW / 2 - 4, 40, 2, 2, 'F');
  doc.setDrawColor(200, 240, 225);
  doc.roundedRect(margin, y, contentW / 2 - 4, 40, 2, 2, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(0, 128, 96);
  doc.text('BILL TO', margin + 4, y + 7);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(17, 24, 39);
  doc.text(buyer.name || 'Customer Name', margin + 4, y + 14);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(75, 85, 99);
  const buyerAddr = [buyer.address, buyer.city, buyer.state, buyer.pincode].filter(Boolean).join(', ');
  const addrLines = doc.splitTextToSize(buyerAddr, contentW / 2 - 12);
  doc.text(addrLines, margin + 4, y + 20);
  if (buyer.gstin) doc.text(`GSTIN: ${buyer.gstin}`, margin + 4, y + 33);
  if (buyer.phone) doc.text(`Phone: ${buyer.phone}`, margin + 4, y + 37);

  // Invoice meta box
  const mx2 = margin + contentW / 2 + 4;
  const bw2 = contentW / 2 - 4;
  doc.setFillColor(248, 255, 254);
  doc.roundedRect(mx2, y, bw2, 40, 2, 2, 'F');
  doc.setDrawColor(200, 240, 225);
  doc.roundedRect(mx2, y, bw2, 40, 2, 2, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(0, 128, 96);
  doc.text('INVOICE DETAILS', mx2 + 4, y + 7);

  const metaRows = [
    ['Invoice No', invoice.invoiceNumber || 'INV-001'],
    ['Date', invoice.date || ''],
    ['Due Date', invoice.dueDate || 'On Receipt'],
    ['Tax Type', taxType === 'igst' ? 'IGST (Interstate)' : 'CGST + SGST (Intrastate)'],
  ];
  if (invoice.poNumber) metaRows.push(['PO Number', invoice.poNumber]);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(75, 85, 99);
  metaRows.forEach((row, i) => {
    const ry = y + 14 + i * 6;
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(55, 65, 81);
    doc.text(row[0] + ':', mx2 + 4, ry);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(75, 85, 99);
    doc.text(row[1], mx2 + bw2 - 4, ry, { align: 'right' });
  });

  y += 48;

  // Items table
  const tableColumns = taxType === 'igst'
    ? ['#', 'Description', 'HSN/SAC', 'Qty', 'Rate (₹)', 'IGST %', 'IGST (₹)', 'Amount (₹)']
    : ['#', 'Description', 'HSN/SAC', 'Qty', 'Rate (₹)', 'GST %', 'CGST (₹)', 'SGST (₹)', 'Amount (₹)'];

  const tableRows = items.map((item, idx) => {
    const qty = parseFloat(item.qty) || 0;
    const rate = parseFloat(item.rate) || 0;
    const taxPct = parseFloat(item.taxRate) || 0;
    const base = qty * rate;
    const taxAmt = base * taxPct / 100;
    const total = base + taxAmt;

    if (taxType === 'igst') {
      return [idx + 1, item.description || '', item.hsn || '', qty, rate.toFixed(2), `${taxPct}%`, taxAmt.toFixed(2), total.toFixed(2)];
    } else {
      const half = taxAmt / 2;
      return [idx + 1, item.description || '', item.hsn || '', qty, rate.toFixed(2), `${taxPct}%`, half.toFixed(2), half.toFixed(2), total.toFixed(2)];
    }
  });

  autoTable(doc, {
    startY: y,
    head: [tableColumns],
    body: tableRows,
    margin: { left: margin, right: margin },
    styles: { fontSize: 8, cellPadding: 3, font: 'helvetica', textColor: [55, 65, 81] },
    headStyles: { fillColor: [0, 76, 63], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 7.5 },
    alternateRowStyles: { fillColor: [248, 255, 254] },
    columnStyles: taxType === 'igst'
      ? { 0: { cellWidth: 8 }, 1: { cellWidth: 55 }, 2: { cellWidth: 18 }, 3: { cellWidth: 12 }, 4: { cellWidth: 20 }, 5: { cellWidth: 14 }, 6: { cellWidth: 20 }, 7: { cellWidth: 22, fontStyle: 'bold', textColor: [0, 76, 63] } }
      : { 0: { cellWidth: 7 }, 1: { cellWidth: 45 }, 2: { cellWidth: 16 }, 3: { cellWidth: 10 }, 4: { cellWidth: 18 }, 5: { cellWidth: 12 }, 6: { cellWidth: 18 }, 7: { cellWidth: 18 }, 8: { cellWidth: 20, fontStyle: 'bold', textColor: [0, 76, 63] } },
  });

  y = doc.lastAutoTable.finalY + 6;

  // Totals
  const subtotal = items.reduce((s, item) => s + (parseFloat(item.qty) || 0) * (parseFloat(item.rate) || 0), 0);
  const totalTax = items.reduce((s, item) => {
    const base = (parseFloat(item.qty) || 0) * (parseFloat(item.rate) || 0);
    return s + base * (parseFloat(item.taxRate) || 0) / 100;
  }, 0);
  const discountAmt = parseFloat(discount) || 0;
  const grandTotal = subtotal + totalTax - discountAmt;

  const totalsX = pageW - margin - 70;
  const labelsX = totalsX;
  const valuesX = pageW - margin;

  const drawTotalRow = (label, value, bold = false, color = [55, 65, 81]) => {
    if (bold) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
    } else {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
    }
    doc.setTextColor(...color);
    doc.text(label, labelsX, y);
    doc.text(`Rs. ${value}`, valuesX, y, { align: 'right' });
    y += bold ? 8 : 6;
  };

  doc.setDrawColor(225, 230, 235);
  doc.line(totalsX, y - 2, pageW - margin, y - 2);
  y += 2;

  drawTotalRow('Subtotal:', subtotal.toFixed(2));
  if (taxType === 'igst') {
    drawTotalRow('IGST:', totalTax.toFixed(2));
  } else {
    drawTotalRow('CGST:', (totalTax / 2).toFixed(2));
    drawTotalRow('SGST:', (totalTax / 2).toFixed(2));
  }
  if (discountAmt > 0) drawTotalRow('Discount:', `-${discountAmt.toFixed(2)}`, false, [220, 38, 38]);

  doc.setDrawColor(0, 76, 63);
  doc.setLineWidth(0.5);
  doc.line(totalsX, y - 1, pageW - margin, y - 1);
  y += 2;
  drawTotalRow('Grand Total:', grandTotal.toFixed(2), true, [0, 76, 63]);

  // Amount in words
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(8);
  doc.setTextColor(107, 114, 128);
  const words = numberToWords(grandTotal);
  const wordLines = doc.splitTextToSize(`Amount in Words: ${words}`, contentW);
  doc.text(wordLines, margin, y + 4);
  y += wordLines.length * 5 + 10;

  // Bank Details
  if (bankDetails && (bankDetails.bankName || bankDetails.accountNumber)) {
    if (y > 240) { doc.addPage(); y = 20; }
    doc.setFillColor(248, 255, 254);
    doc.roundedRect(margin, y, contentW / 2 - 4, 36, 2, 2, 'F');
    doc.setDrawColor(200, 240, 225);
    doc.roundedRect(margin, y, contentW / 2 - 4, 36, 2, 2, 'S');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(0, 128, 96);
    doc.text('BANK DETAILS', margin + 4, y + 7);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(55, 65, 81);
    const bankRows = [
      ['Bank', bankDetails.bankName],
      ['A/C No', bankDetails.accountNumber],
      ['IFSC', bankDetails.ifsc],
      ['Branch', bankDetails.branch],
    ].filter(r => r[1]);
    bankRows.forEach((row, i) => {
      doc.setFont('helvetica', 'bold');
      doc.text(row[0] + ':', margin + 4, y + 14 + i * 5.5);
      doc.setFont('helvetica', 'normal');
      doc.text(row[1], margin + 24, y + 14 + i * 5.5);
    });
  }

  // Notes and Terms
  if (notes || terms) {
    const nx = margin + contentW / 2 + 4;
    if (notes) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(0, 128, 96);
      doc.text('NOTES:', nx, y + 7);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(107, 114, 128);
      const noteLines = doc.splitTextToSize(notes, contentW / 2 - 8);
      doc.text(noteLines, nx, y + 13);
    }
    if (terms) {
      const ty = notes ? y + 24 : y + 7;
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(0, 128, 96);
      doc.text('TERMS & CONDITIONS:', nx, ty);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(107, 114, 128);
      const termLines = doc.splitTextToSize(terms, contentW / 2 - 8);
      doc.text(termLines, nx, ty + 6);
    }
  }

  // Footer
  doc.setFillColor(0, 76, 63);
  doc.rect(0, 282, pageW, 15, 'F');
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(200, 240, 230);
  doc.text('Generated by BillMatic — Indian Invoice Generator', margin, 290);
  doc.text('Thank you for your business!', pageW - margin, 290, { align: 'right' });

  // Save
  doc.save(`Invoice-${invoice.invoiceNumber || 'INV-001'}.pdf`);
}
