import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
  }).format(amount);
};

const numberToWords = (num) => {
  const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
    'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  const convert = (n) => {
    if (n < 20) return ones[n];
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 ? ' ' + ones[n % 10] : '');
    if (n < 1000) return ones[Math.floor(n / 100)] + ' Hundred' + (n % 100 ? ' ' + convert(n % 100) : '');
    if (n < 100000) return convert(Math.floor(n / 1000)) + ' Thousand' + (n % 1000 ? ' ' + convert(n % 1000) : '');
    if (n < 10000000) return convert(Math.floor(n / 100000)) + ' Lakh' + (n % 100000 ? ' ' + convert(n % 100000) : '');
    return convert(Math.floor(n / 10000000)) + ' Crore' + (n % 10000000 ? ' ' + convert(n % 10000000) : '');
  };

  const intPart = Math.floor(num);
  const decPart = Math.round((num - intPart) * 100);
  let words = convert(intPart) || 'Zero';
  if (decPart > 0) words += ' and ' + convert(decPart) + ' Paise';
  return 'Rupees ' + words + ' Only';
};

export const generateInvoicePDF = (data) => {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const pageW = doc.internal.pageSize.getWidth();
  const margin = 15;
  let y = margin;

  // --- HEADER BACKGROUND ---
  doc.setFillColor(0, 111, 187);
  doc.rect(0, 0, pageW, 45, 'F');

  // TAX INVOICE title
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text('TAX INVOICE', margin, 18);

  // Invoice number & date on right
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Invoice No:', pageW - margin - 50, 12, { align: 'left' });
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text(data.invoiceNumber || 'INV-001', pageW - margin - 50 + 22, 12, { align: 'left' });

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Date:', pageW - margin - 50, 20, { align: 'left' });
  doc.setFont('helvetica', 'bold');
  doc.text(data.invoiceDate || '-', pageW - margin - 50 + 12, 20, { align: 'left' });

  if (data.dueDate) {
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text('Due Date:', pageW - margin - 50, 28, { align: 'left' });
    doc.setFont('helvetica', 'bold');
    doc.text(data.dueDate, pageW - margin - 50 + 20, 28, { align: 'left' });
  }

  if (data.poNumber) {
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text('PO No:', pageW - margin - 50, 36, { align: 'left' });
    doc.setFont('helvetica', 'bold');
    doc.text(data.poNumber, pageW - margin - 50 + 15, 36, { align: 'left' });
  }

  y = 52;

  // --- FROM / TO SECTION ---
  doc.setTextColor(0, 111, 187);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text('FROM (SELLER)', margin, y);
  doc.text('TO (BUYER)', pageW / 2 + 5, y);

  y += 5;
  doc.setTextColor(30, 30, 30);

  // Seller
  const sellerX = margin;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text(data.sellerName || '-', sellerX, y);
  y += 5;
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(80, 80, 80);
  if (data.sellerAddress) {
    const lines = doc.splitTextToSize(data.sellerAddress, 80);
    doc.text(lines, sellerX, y);
    y += lines.length * 4.5;
  }
  if (data.sellerCity || data.sellerState || data.sellerPincode) {
    doc.text(`${data.sellerCity || ''}, ${data.sellerState || ''} - ${data.sellerPincode || ''}`, sellerX, y);
    y += 5;
  }
  if (data.sellerPhone) { doc.text(`📞 ${data.sellerPhone}`, sellerX, y); y += 5; }
  if (data.sellerEmail) { doc.text(`✉ ${data.sellerEmail}`, sellerX, y); y += 5; }
  if (data.sellerGSTIN) {
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0, 111, 187);
    doc.text(`GSTIN: ${data.sellerGSTIN}`, sellerX, y);
    y += 5;
  }

  // Buyer (right column)
  let y2 = 52 + 5;
  const buyerX = pageW / 2 + 5;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 30, 30);
  doc.text(data.buyerName || '-', buyerX, y2);
  y2 += 5;
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(80, 80, 80);
  if (data.buyerAddress) {
    const lines = doc.splitTextToSize(data.buyerAddress, 80);
    doc.text(lines, buyerX, y2);
    y2 += lines.length * 4.5;
  }
  if (data.buyerCity || data.buyerState || data.buyerPincode) {
    doc.text(`${data.buyerCity || ''}, ${data.buyerState || ''} - ${data.buyerPincode || ''}`, buyerX, y2);
    y2 += 5;
  }
  if (data.buyerPhone) { doc.text(`📞 ${data.buyerPhone}`, buyerX, y2); y2 += 5; }
  if (data.buyerEmail) { doc.text(`✉ ${data.buyerEmail}`, buyerX, y2); y2 += 5; }
  if (data.buyerGSTIN) {
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0, 111, 187);
    doc.text(`GSTIN: ${data.buyerGSTIN}`, buyerX, y2);
    y2 += 5;
  }
  if (data.buyerPAN) {
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(0, 111, 187);
    doc.text(`PAN: ${data.buyerPAN}`, buyerX, y2);
  }

  y = Math.max(y, y2) + 6;

  // Divider
  doc.setDrawColor(225, 227, 229);
  doc.setLineWidth(0.4);
  doc.line(margin, y, pageW - margin, y);
  y += 7;

  // --- ITEMS TABLE ---
  const useIGST = data.sellerState !== data.buyerState;

  const tableHead = [['#', 'Description', 'HSN/SAC', 'Qty', 'Unit', 'Rate (₹)', 'Disc%', useIGST ? 'IGST%' : 'CGST%', useIGST ? '' : 'SGST%', 'Amount (₹)']];
  if (useIGST) tableHead[0].splice(8, 1); // remove SGST col for IGST

  const tableBody = (data.items || []).map((item, i) => {
    const qty = parseFloat(item.quantity) || 0;
    const rate = parseFloat(item.rate) || 0;
    const disc = parseFloat(item.discount) || 0;
    const gstRate = parseFloat(item.gstRate) || 0;
    const taxable = qty * rate * (1 - disc / 100);
    const amount = taxable + (taxable * gstRate / 100);

    if (useIGST) {
      return [i + 1, item.description || '-', item.hsnCode || '-', qty, item.unit || 'Nos', `₹${rate.toFixed(2)}`, `${disc}%`, `${gstRate}%`, `₹${amount.toFixed(2)}`];
    } else {
      const halfGst = gstRate / 2;
      return [i + 1, item.description || '-', item.hsnCode || '-', qty, item.unit || 'Nos', `₹${rate.toFixed(2)}`, `${disc}%`, `${halfGst}%`, `${halfGst}%`, `₹${amount.toFixed(2)}`];
    }
  });

  autoTable(doc, {
    startY: y,
    head: tableHead,
    body: tableBody,
    theme: 'grid',
    headStyles: { fillColor: [0, 111, 187], textColor: 255, fontSize: 8, fontStyle: 'bold', halign: 'center' },
    bodyStyles: { fontSize: 8, textColor: [30, 30, 30] },
    columnStyles: {
      0: { halign: 'center', cellWidth: 8 },
      1: { cellWidth: 45 },
      2: { halign: 'center', cellWidth: 18 },
      3: { halign: 'center', cellWidth: 12 },
      4: { halign: 'center', cellWidth: 12 },
      5: { halign: 'right', cellWidth: 18 },
      6: { halign: 'center', cellWidth: 12 },
      7: { halign: 'center', cellWidth: 14 },
      8: { halign: 'center', cellWidth: 14 },
      9: { halign: 'right', cellWidth: 22 },
    },
    alternateRowStyles: { fillColor: [249, 250, 251] },
    margin: { left: margin, right: margin },
  });

  y = doc.lastAutoTable.finalY + 8;

  // --- TOTALS ---
  const subtotal = (data.items || []).reduce((sum, item) => {
    const qty = parseFloat(item.quantity) || 0;
    const rate = parseFloat(item.rate) || 0;
    const disc = parseFloat(item.discount) || 0;
    return sum + qty * rate * (1 - disc / 100);
  }, 0);

  const totalGST = (data.items || []).reduce((sum, item) => {
    const qty = parseFloat(item.quantity) || 0;
    const rate = parseFloat(item.rate) || 0;
    const disc = parseFloat(item.discount) || 0;
    const gstRate = parseFloat(item.gstRate) || 0;
    const taxable = qty * rate * (1 - disc / 100);
    return sum + (taxable * gstRate / 100);
  }, 0);

  const grandTotal = subtotal + totalGST;

  const totalsX = pageW - margin - 75;
  const totalsW = 75;

  doc.setFillColor(249, 250, 251);
  doc.rect(totalsX, y, totalsW, useIGST ? 28 : 36, 'F');

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(80, 80, 80);

  let ty = y + 7;
  doc.text('Subtotal (before tax):', totalsX + 3, ty);
  doc.text(formatCurrency(subtotal), totalsX + totalsW - 3, ty, { align: 'right' });
  ty += 6;

  if (!useIGST) {
    doc.text(`CGST (${(data.items?.[0]?.gstRate || 0) / 2}%):`, totalsX + 3, ty);
    doc.text(formatCurrency(totalGST / 2), totalsX + totalsW - 3, ty, { align: 'right' });
    ty += 6;
    doc.text(`SGST (${(data.items?.[0]?.gstRate || 0) / 2}%):`, totalsX + 3, ty);
    doc.text(formatCurrency(totalGST / 2), totalsX + totalsW - 3, ty, { align: 'right' });
    ty += 6;
  } else {
    doc.text(`IGST (${data.items?.[0]?.gstRate || 0}%):`, totalsX + 3, ty);
    doc.text(formatCurrency(totalGST), totalsX + totalsW - 3, ty, { align: 'right' });
    ty += 6;
  }

  doc.setFillColor(0, 111, 187);
  doc.rect(totalsX, ty - 4, totalsW, 10, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('GRAND TOTAL:', totalsX + 3, ty + 2);
  doc.text(formatCurrency(grandTotal), totalsX + totalsW - 3, ty + 2, { align: 'right' });

  y = ty + 10;

  // Amount in words
  doc.setTextColor(80, 80, 80);
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'italic');
  const words = numberToWords(grandTotal);
  const wordLines = doc.splitTextToSize(`Amount in Words: ${words}`, pageW - 2 * margin - 80);
  doc.text(wordLines, margin, y - 4);

  y += 14;

  // --- BANK DETAILS ---
  if (data.bankName || data.accountNumber) {
    doc.setTextColor(0, 111, 187);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('BANK DETAILS', margin, y);
    y += 5;
    doc.setTextColor(60, 60, 60);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    if (data.bankName) { doc.text(`Bank: ${data.bankName}`, margin, y); y += 5; }
    if (data.accountNumber) { doc.text(`A/C No: ${data.accountNumber}`, margin, y); y += 5; }
    if (data.ifscCode) { doc.text(`IFSC: ${data.ifscCode}`, margin, y); y += 5; }
    if (data.accountType) { doc.text(`Type: ${data.accountType}`, margin, y); y += 5; }
  }

  // --- NOTES ---
  if (data.notes) {
    const notesX = pageW / 2 + 5;
    let ny = y - (data.bankName || data.accountNumber ? 20 : 5);
    doc.setTextColor(0, 111, 187);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('NOTES & TERMS', notesX, ny);
    ny += 5;
    doc.setTextColor(80, 80, 80);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    const noteLines = doc.splitTextToSize(data.notes, 80);
    doc.text(noteLines, notesX, ny);
  }

  y += 10;

  // --- SIGNATURE ---
  doc.setDrawColor(200, 200, 200);
  doc.line(margin, y, pageW - margin, y);
  y += 8;

  doc.setTextColor(60, 60, 60);
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.text('This is a computer-generated invoice. No physical signature required.', margin, y);

  doc.setFont('helvetica', 'bold');
  doc.text(`For ${data.sellerName || 'Seller'}`, pageW - margin - 50, y - 12, { align: 'center' });
  doc.setDrawColor(30, 30, 30);
  doc.line(pageW - margin - 70, y, pageW - margin, y);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 100, 100);
  doc.text('Authorised Signatory', pageW - margin - 50, y + 5, { align: 'center' });

  // Footer
  y += 12;
  doc.setFillColor(0, 111, 187);
  doc.rect(0, doc.internal.pageSize.getHeight() - 10, pageW, 10, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(7.5);
  doc.text('Generated by BillEasy – Indian Invoice Generator', pageW / 2, doc.internal.pageSize.getHeight() - 4, { align: 'center' });

  const fileName = `Invoice_${data.invoiceNumber || 'INV001'}_${data.buyerName?.replace(/\s/g, '_') || 'Customer'}.pdf`;
  doc.save(fileName);
};
