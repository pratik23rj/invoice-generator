import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { formatINR, numberToWords } from './indianData.js';

export function generateInvoicePDF(data) {
  const { seller, buyer, invoice, items, totals } = data;
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

  const PAGE_W = 210;
  const MARGIN = 14;
  const CONTENT_W = PAGE_W - MARGIN * 2;
  const PRIMARY = [0, 128, 96];
  const DARK = [26, 26, 46];
  const GRAY = [109, 113, 117];
  const LIGHT_GRAY = [248, 249, 250];
  const BORDER = [225, 227, 229];

  // ── Header bar ──────────────────────────────────────────────────────────────
  doc.setFillColor(...DARK);
  doc.rect(0, 0, PAGE_W, 38, 'F');

  // Company name
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(255, 255, 255);
  doc.text(seller.name || 'Your Company', MARGIN, 14);

  // Company details
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(200, 200, 210);
  const sellerAddr = [seller.address, seller.city, seller.state].filter(Boolean).join(', ');
  if (sellerAddr) doc.text(sellerAddr, MARGIN, 20);
  const sellerContact = [seller.phone && `Ph: ${seller.phone}`, seller.email].filter(Boolean).join('  |  ');
  if (sellerContact) doc.text(sellerContact, MARGIN, 25.5);
  if (seller.gstin) doc.text(`GSTIN: ${seller.gstin}`, MARGIN, 31);
  if (seller.pan) doc.text(`PAN: ${seller.pan}`, MARGIN + 40, 31);

  // INVOICE title (right side)
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(22);
  doc.setTextColor(...PRIMARY);
  doc.text('TAX INVOICE', PAGE_W - MARGIN, 15, { align: 'right' });

  // Invoice meta
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(200, 200, 210);
  doc.text(`Invoice No: ${invoice.number}`, PAGE_W - MARGIN, 22, { align: 'right' });
  doc.text(`Date: ${invoice.date}`, PAGE_W - MARGIN, 27.5, { align: 'right' });
  if (invoice.dueDate) doc.text(`Due Date: ${invoice.dueDate}`, PAGE_W - MARGIN, 33, { align: 'right' });

  let y = 44;

  // ── Bill To / Bill From ──────────────────────────────────────────────────────
  const boxH = 36;
  // Left box (Bill To)
  doc.setFillColor(...LIGHT_GRAY);
  doc.roundedRect(MARGIN, y, CONTENT_W / 2 - 3, boxH, 2, 2, 'F');
  doc.setDrawColor(...BORDER);
  doc.setLineWidth(0.3);
  doc.roundedRect(MARGIN, y, CONTENT_W / 2 - 3, boxH, 2, 2, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(...PRIMARY);
  doc.text('BILL TO', MARGIN + 4, y + 5.5);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(...DARK);
  doc.text(buyer.name || 'Customer Name', MARGIN + 4, y + 11.5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(80, 80, 80);
  let by = y + 17;
  if (buyer.address) { doc.text(buyer.address, MARGIN + 4, by); by += 5; }
  const buyerCityState = [buyer.city, buyer.state].filter(Boolean).join(', ');
  if (buyerCityState) { doc.text(buyerCityState, MARGIN + 4, by); by += 5; }
  if (buyer.gstin) doc.text(`GSTIN: ${buyer.gstin}`, MARGIN + 4, by);

  // Right box (Invoice Details)
  const rx = MARGIN + CONTENT_W / 2 + 3;
  const rw = CONTENT_W / 2 - 3;
  doc.setFillColor(...LIGHT_GRAY);
  doc.roundedRect(rx, y, rw, boxH, 2, 2, 'F');
  doc.setDrawColor(...BORDER);
  doc.roundedRect(rx, y, rw, boxH, 2, 2, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(...PRIMARY);
  doc.text('INVOICE DETAILS', rx + 4, y + 5.5);

  const metaRows = [
    ['Place of Supply', invoice.placeOfSupply || '—'],
    ['Payment Terms', invoice.paymentTerms || '—'],
    ['PO Number', invoice.poNumber || '—'],
  ];
  doc.setFontSize(8);
  let my = y + 12;
  metaRows.forEach(([label, value]) => {
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 100, 100);
    doc.text(label + ':', rx + 4, my);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...DARK);
    doc.text(value, rx + rw - 4, my, { align: 'right' });
    my += 6.5;
  });

  y += boxH + 7;

  // ── Items table ──────────────────────────────────────────────────────────────
  const isInterState = seller.state !== buyer.state && buyer.state;
  const tableHead = isInterState
    ? [['#', 'Description', 'HSN/SAC', 'Qty', 'Unit', 'Rate (₹)', 'IGST %', 'IGST (₹)', 'Amount (₹)']]
    : [['#', 'Description', 'HSN/SAC', 'Qty', 'Unit', 'Rate (₹)', 'GST %', 'CGST (₹)', 'SGST (₹)', 'Amount (₹)']];

  const tableBody = items.map((item, i) => {
    const qty = parseFloat(item.qty) || 0;
    const rate = parseFloat(item.rate) || 0;
    const gstRate = parseFloat(item.gstRate) || 0;
    const taxable = qty * rate;
    const tax = taxable * gstRate / 100;
    const total = taxable + tax;
    if (isInterState) {
      return [
        i + 1, item.description || '—', item.hsn || '—',
        qty, item.unit || 'NOS',
        formatINR(rate), `${gstRate}%`, formatINR(tax), formatINR(total)
      ];
    }
    const halfTax = tax / 2;
    return [
      i + 1, item.description || '—', item.hsn || '—',
      qty, item.unit || 'NOS',
      formatINR(rate), `${gstRate}%`, formatINR(halfTax), formatINR(halfTax), formatINR(total)
    ];
  });

  autoTable(doc, {
    startY: y,
    head: tableHead,
    body: tableBody,
    margin: { left: MARGIN, right: MARGIN },
    styles: {
      font: 'helvetica', fontSize: 8, cellPadding: 3,
      textColor: DARK, lineColor: BORDER, lineWidth: 0.2,
    },
    headStyles: {
      fillColor: DARK, textColor: [255, 255, 255], fontStyle: 'bold',
      fontSize: 7.5, halign: 'center',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 8 },
      1: { cellWidth: 'auto' },
      2: { halign: 'center', cellWidth: 18 },
      3: { halign: 'center', cellWidth: 12 },
      4: { halign: 'center', cellWidth: 14 },
      5: { halign: 'right', cellWidth: 20 },
      6: { halign: 'center', cellWidth: 14 },
      7: { halign: 'right', cellWidth: 20 },
      ...(isInterState ? { 8: { halign: 'right', cellWidth: 22, fontStyle: 'bold' } }
        : { 8: { halign: 'right', cellWidth: 20 }, 9: { halign: 'right', cellWidth: 22, fontStyle: 'bold' } }),
    },
    alternateRowStyles: { fillColor: [250, 251, 251] },
    didParseCell(data) {
      if (data.section === 'head') {
        data.cell.styles.halign = 'center';
      }
    },
  });

  y = doc.lastAutoTable.finalY + 8;

  // ── Totals ───────────────────────────────────────────────────────────────────
  const totalsX = MARGIN + CONTENT_W * 0.52;
  const totalsW = CONTENT_W * 0.48;

  // Left: Notes + Bank
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(...GRAY);
  doc.text('NOTES / TERMS', MARGIN, y);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(80, 80, 80);
  const notes = invoice.notes || 'Thank you for your business!';
  const noteLines = doc.splitTextToSize(notes, CONTENT_W * 0.48);
  doc.text(noteLines, MARGIN, y + 5);

  if (seller.bankName) {
    let bY = y + 5 + noteLines.length * 4.5 + 5;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(...GRAY);
    doc.text('BANK DETAILS', MARGIN, bY);
    bY += 5;
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(80, 80, 80);
    if (seller.bankName) { doc.text(`Bank: ${seller.bankName}`, MARGIN, bY); bY += 4.5; }
    if (seller.accountNo) { doc.text(`Account No: ${seller.accountNo}`, MARGIN, bY); bY += 4.5; }
    if (seller.ifsc) { doc.text(`IFSC: ${seller.ifsc}`, MARGIN, bY); }
  }

  // Right: totals box
  const rows = [
    ['Subtotal', formatINR(totals.subtotal)],
    ...(isInterState
      ? [['IGST', formatINR(totals.totalTax)]]
      : [['CGST', formatINR(totals.totalTax / 2)], ['SGST', formatINR(totals.totalTax / 2)]]),
  ];
  if (invoice.discount) rows.push(['Discount', `- ₹${formatINR(parseFloat(invoice.discount))}`]);

  let ty = y;
  doc.setLineWidth(0.3);
  doc.setDrawColor(...BORDER);
  doc.roundedRect(totalsX, ty, totalsW, rows.length * 8 + 14, 2, 2, 'S');

  rows.forEach(([label, value], i) => {
    const ry = ty + 6 + i * 8;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 100, 100);
    doc.text(label, totalsX + 5, ry);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...DARK);
    doc.text(value, totalsX + totalsW - 5, ry, { align: 'right' });
  });

  // Grand total bar
  const grandY = ty + rows.length * 8 + 8;
  doc.setFillColor(...PRIMARY);
  doc.roundedRect(totalsX, grandY, totalsW, 12, 2, 2, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(255, 255, 255);
  doc.text('GRAND TOTAL', totalsX + 5, grandY + 8);
  doc.text(`₹ ${formatINR(totals.grandTotal)}`, totalsX + totalsW - 5, grandY + 8, { align: 'right' });

  y = Math.max(grandY + 20, y + 45);

  // Amount in words
  doc.setFillColor(...[227, 241, 237]);
  doc.roundedRect(MARGIN, y, CONTENT_W, 11, 2, 2, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(...PRIMARY);
  doc.text('Amount in Words:', MARGIN + 4, y + 7);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(0, 80, 60);
  const words = numberToWords(totals.grandTotal);
  doc.text(words, MARGIN + 36, y + 7);

  y += 18;

  // ── Signature ────────────────────────────────────────────────────────────────
  const sigX = MARGIN + CONTENT_W - 70;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(100, 100, 100);
  doc.text('For ' + (seller.name || 'Company Name'), sigX, y);
  y += 20;
  doc.setLineWidth(0.4);
  doc.setDrawColor(100, 100, 100);
  doc.line(sigX, y, sigX + 70, y);
  doc.text('Authorised Signatory', sigX, y + 4.5);

  // ── Footer ───────────────────────────────────────────────────────────────────
  doc.setFillColor(...DARK);
  doc.rect(0, 287, PAGE_W, 10, 'F');
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(160, 160, 180);
  doc.text('This is a computer-generated invoice. No signature required.', PAGE_W / 2, 293, { align: 'center' });

  // Save
  const filename = `Invoice-${invoice.number || 'draft'}.pdf`;
  doc.save(filename);
}
